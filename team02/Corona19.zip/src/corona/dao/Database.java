package corona.dao;

public class Database {

}
